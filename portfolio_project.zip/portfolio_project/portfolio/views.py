from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from .models import Profile, Skill, Project

def home(request):
    profile = Profile.objects.first()
    skills = Skill.objects.all()
    projects = Project.objects.all()

    context = {
        "profile": profile,
        "skills": skills,
        "projects": projects
    }

    return render(request, "home.html", context)